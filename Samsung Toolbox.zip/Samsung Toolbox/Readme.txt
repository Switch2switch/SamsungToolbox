This software is not maintained or created by Samsung.
Created by Twitter.com/Switch2Switch1

Make sure you install ADB and your device drivers.